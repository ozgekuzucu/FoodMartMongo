const shadows = [
  `none`,
  `0px 0px 5px 1px rgba(0, 0, 0, 0.2)`,
  `0px 4px 10px 2px rgba(0, 0, 0, 0.2)`,
  `0px 4px 4px 0px rgba(0, 0, 0, 0.25)`,
  `0px 0px 4px 0px rgba(255, 142, 41, 0.1)`,
  `0px 0px 5px 0px rgba(0, 0, 0, 0.15)`,
];

export default shadows;
