import { Outlet } from 'react-router-dom';

const App = () => <Outlet />;

export default App;
